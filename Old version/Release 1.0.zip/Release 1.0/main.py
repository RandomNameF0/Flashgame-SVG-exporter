import os
from xml.etree import ElementTree as ET
import cairosvg
from io import BytesIO
from PIL import Image

from concurrent.futures import ProcessPoolExecutor
import os

# Define the paths
svg_folder = 'SVGFolder'
output_folder = 'OutputFile'

# Target dimensions
target_width = 2000
target_height = 2000

# Function to process each SVG file and its shapes
def process_svg(svg_file, scale_factor):
    # Full path to the SVG file
    input_svg_path = os.path.join(svg_folder, svg_file)

    # Get the base name of the SVG file without extension
    svg_name = os.path.splitext(svg_file)[0]

    # Create a folder for this SVG inside the output folder
    svg_output_folder = os.path.join(output_folder, svg_name)
    os.makedirs(svg_output_folder, exist_ok=True)

    # Parse the SVG content
    tree = ET.parse(input_svg_path)
    root = tree.getroot()

    # Namespace for SVG
    namespace = '{http://www.w3.org/2000/svg}'

    # Find the 'defs' section
    defs = root.find(f'{namespace}defs')

    # Collect all shape IDs
    shape_ids = []
    if defs is not None:
        for shape_elem in defs.findall(f'{namespace}g'):
            shape_id = shape_elem.attrib.get('id')
            if shape_id and shape_id.startswith('shape'):
                shape_ids.append(shape_id)

    # Generate the include/exclude pattern
    total_shapes = len(shape_ids)
    print(f"Processing '{svg_name}': Total shapes: {total_shapes}\n")

    # Generate PNGs with the given scale factor
    for loop_index, shape_id in enumerate(shape_ids, start=1):
        # Create new parse each time
        tree = ET.parse(input_svg_path)
        root = tree.getroot()
        newDef = root.find(f'{namespace}defs')

        print(f"Processing shape {loop_index}/{total_shapes}: {shape_id}")
        for sid in shape_ids:
            if sid != shape_id:
                for shape_elem in newDef.findall(f'{namespace}g'):
                    if shape_elem.attrib.get('id') == sid:
                        newDef.remove(shape_elem)

        # Convert the modified SVG to PNG
        svg_bytes = BytesIO()
        tree.write(svg_bytes, encoding='utf-8')
        svg_content = svg_bytes.getvalue()

        filename = f"shape_{loop_index}.png"
        filepath = os.path.join(svg_output_folder, filename)

        # Use the given scale for the final PNG generation
        cairosvg.svg2png(bytestring=svg_content, write_to=filepath, scale=scale_factor)
        print(f"Saved: {filepath}")

        # Now, automatically scale the PNG to around 2000x2000 while maintaining aspect ratio
        scale_png(filepath)

    print(f"All shapes from '{svg_name}' have been saved in '{svg_output_folder}'\n")


# Function to calculate the scale factor based on the bounding box size
def get_scale_factor(input_svg_path):
    # Convert the SVG with the default scale to check its bounding box
    svg_bytes = BytesIO()
    tree = ET.parse(input_svg_path)
    root = tree.getroot()
    tree.write(svg_bytes, encoding='utf-8')
    svg_content = svg_bytes.getvalue()

    output_png = BytesIO()
    cairosvg.svg2png(bytestring=svg_content, write_to=output_png, scale=1)

    # Load the PNG and check its size
    with Image.open(output_png) as img:
        width, height = img.size

    # Calculate the scale factor to get close to 2000x2000
    scale_factor = 1
    if width > height:
        scale_factor = target_width / width
    else:
        scale_factor = target_height / height

    # Ensure the scale doesn't exceed 2.0 (adjust if needed)
    scale_factor = min(scale_factor, 2.0)

    print(f"Calculated scale factor: {scale_factor}")
    return scale_factor

# Function to scale the PNG to around 2000x2000 while maintaining aspect ratio
def scale_png(png_filepath):
    with Image.open(png_filepath) as img:
        width, height = img.size

        # Determine the scaling factor based on the target size
        target_size = 2000
        scale_factor = 1

        if width > height:
            if width > target_size:
                scale_factor = target_size / width
        else:
            if height > target_size:
                scale_factor = target_size / height

        # Calculate new size keeping the aspect ratio
        new_width = int(width * scale_factor)
        new_height = int(height * scale_factor)

        # Ensure that the image is not larger than 2000x2000
        new_width = min(new_width, target_size)
        new_height = min(new_height, target_size)

        # Resize the image
        img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

        # Save the resized image back
        img.save(png_filepath)
        print(f"Scaled image saved: {png_filepath}")



# Loop through each SVG file in SVGFolder
def main():
    # Get the first SVG file in the folder to determine the scale factor
    svg_files = [f for f in os.listdir(svg_folder) if f.endswith('.svg')]
    if not svg_files:
        print("No SVG files found in the folder.")
        return

    first_svg_file = svg_files[0]  # Pick the first SVG file to calculate the scale factor
    input_svg_path = os.path.join(svg_folder, first_svg_file)
    scale_factor = get_scale_factor(input_svg_path)

    # Process all SVG files in parallel with the calculated scale factor
    with ProcessPoolExecutor() as executor:
        futures = [executor.submit(process_svg, svg_file, scale_factor) for svg_file in svg_files]
        for future in futures:
            # Optionally handle exceptions or progress tracking
            try:
                future.result()
            except Exception as e:
                print(f"Error processing file: {e}")

    print("Processing complete!")

if __name__ == "__main__":
    main()
