import os
from xml.etree import ElementTree as ET
import cairosvg
from io import BytesIO

# Path to input SVG
input_svg_path = 'input_file.svg'

# Get the base name of the SVG file without extension
svg_name = os.path.splitext(os.path.basename(input_svg_path))[0]

# Create a folder based on the SVG file name
output_folder = os.path.join(os.getcwd(), svg_name)
os.makedirs(output_folder, exist_ok=True)

# Parse the SVG content
tree = ET.parse(input_svg_path)
root = tree.getroot()

# Namespace for SVG
namespace = '{http://www.w3.org/2000/svg}'

# Find the 'defs' section
defs = root.find(f'{namespace}defs')

# Collect all shape IDs
shape_ids = []
if defs is not None:
    for shape_elem in defs.findall(f'{namespace}g'):
        shape_id = shape_elem.attrib.get('id')
        if shape_id and shape_id.startswith('shape'):
            shape_ids.append(shape_id)

# Generate the include/exclude pattern
total_shapes = len(shape_ids)
print(f"Total shapes: {total_shapes}\n")

for loop_index, shape_id in enumerate(shape_ids, start=1):
    # Create new parse each time
    tree = ET.parse(input_svg_path)
    root = tree.getroot()
    newDef = root.find(f'{namespace}defs')

    print(f"Processing shape {loop_index}/{total_shapes}: {shape_id}")
    for sid in shape_ids:
        if sid != shape_id:
            for shape_elem in newDef.findall(f'{namespace}g'):
                if shape_elem.attrib.get('id') == sid:
                    newDef.remove(shape_elem)

    # Convert the modified SVG to PNG
    svg_bytes = BytesIO()
    tree.write(svg_bytes, encoding='utf-8')
    svg_content = svg_bytes.getvalue()

    filename = f"shape_{loop_index}.png"
    filepath = os.path.join(output_folder, filename)

    cairosvg.svg2png(bytestring=svg_content, write_to=filepath, scale=4)
    print(f"Saved: {filepath}")

print(f"All shapes have been saved in '{output_folder}'")
