import os
from xml.etree import ElementTree as ET
import cairosvg
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor

# Define the paths
svg_folder = 'SVGFolder'
output_folder = 'OutputFile'
scale = 0.68
# Function to process each SVG file and its shapes
def process_svg(svg_file):
    # Full path to the SVG file
    input_svg_path = os.path.join(svg_folder, svg_file)

    # Get the base name of the SVG file without extension
    svg_name = os.path.splitext(svg_file)[0]

    # Create a folder for this SVG inside the output folder
    svg_output_folder = os.path.join(output_folder, svg_name)
    os.makedirs(svg_output_folder, exist_ok=True)

    # Parse the SVG content
    tree = ET.parse(input_svg_path)
    root = tree.getroot()

    # Namespace for SVG
    namespace = '{http://www.w3.org/2000/svg}'

    # Find the 'defs' section
    defs = root.find(f'{namespace}defs')

    # Collect all shape IDs
    shape_ids = []
    if defs is not None:
        for shape_elem in defs.findall(f'{namespace}g'):
            shape_id = shape_elem.attrib.get('id')
            if shape_id and shape_id.startswith('shape'):
                shape_ids.append(shape_id)

    # Generate the include/exclude pattern
    total_shapes = len(shape_ids)
    print(f"Processing '{svg_name}': Total shapes: {total_shapes}\n")

    for loop_index, shape_id in enumerate(shape_ids, start=1):
        # Create new parse each time
        tree = ET.parse(input_svg_path)
        root = tree.getroot()
        newDef = root.find(f'{namespace}defs')

        print(f"Processing shape {loop_index}/{total_shapes}: {shape_id}")
        for sid in shape_ids:
            if sid != shape_id:
                for shape_elem in newDef.findall(f'{namespace}g'):
                    if shape_elem.attrib.get('id') == sid:
                        newDef.remove(shape_elem)

        # Convert the modified SVG to PNG
        svg_bytes = BytesIO()
        tree.write(svg_bytes, encoding='utf-8')
        svg_content = svg_bytes.getvalue()

        filename = f"shape_{loop_index}.png"
        filepath = os.path.join(svg_output_folder, filename)

        cairosvg.svg2png(bytestring=svg_content, write_to=filepath, scale=scale)
        print(f"Saved: {filepath}")

    print(f"All shapes from '{svg_name}' have been saved in '{svg_output_folder}'\n")


# Loop through each SVG file in SVGFolder using ThreadPoolExecutor
def main():
    # List of SVG files in the SVG folder
    svg_files = [f for f in os.listdir(svg_folder) if f.endswith('.svg')]

    # Use ThreadPoolExecutor to process each SVG in parallel
    with ThreadPoolExecutor(max_workers=16) as executor:
        executor.map(process_svg, svg_files)

    print("Processing complete!")


if __name__ == "__main__":
    main()
