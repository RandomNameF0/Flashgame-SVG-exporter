import tifffile
from PIL import Image
import numpy as np

# Assuming you have each layer as a separate PNG image (or any format)
layers = ["1.png", "2.png", "3.png"]

# Open the layers and convert them into a list of images
layer_images = []
for layer in layers:
    img = Image.open(layer)
    layer_images.append(img)

# Convert each layer into an image array (which tifffile expects)
image_arrays = [np.array(layer) for layer in layer_images]

# Save as multi-layer TIFF
tifffile.imwrite('output_layers.tiff', image_arrays)
