from xml.etree import ElementTree as ET
import cairosvg

# Path to input SVG and output PNG
input_svg_path = 'input_file.svg'
output_png_path = 'output_file1.png'

# Parse the SVG content
tree = ET.parse(input_svg_path)
root = tree.getroot()

# Find and remove the unwanted 'shape2' group by iterating through the 'defs' section
defs = root.find('{http://www.w3.org/2000/svg}defs')

if defs is not None:
    # Find the shape2 element and remove it
    for shape_elem in defs.findall('{http://www.w3.org/2000/svg}g'):
        if shape_elem.attrib.get('id') == 'shape1':
            defs.remove(shape_elem)
        elif shape_elem.attrib.get('id') == 'shape2':
            defs.remove(shape_elem)
        elif shape_elem.attrib.get('id') == 'shape3':
            pass
            #defs.remove(shape_elem)
        elif shape_elem.attrib.get('id') == 'shape4':
            defs.remove(shape_elem)
        elif shape_elem.attrib.get('id') == 'shape0':
            defs.remove(shape_elem)


# Save the modified SVG with only shape1 (now without shape2)
new_svg_path = 'shape1_only.svg'
tree.write(new_svg_path)

# Convert the new SVG to PNG using cairosvg
cairosvg.svg2png(url=new_svg_path, write_to=output_png_path,scale=6)

print(f"Conversion successful! PNG saved as {output_png_path}")
