from xml.etree import ElementTree as ET
import cairosvg

# Path to input SVG
input_svg_path = 'input_file.svg'

# Parse the SVG content
tree = ET.parse(input_svg_path)
root = tree.getroot()

# Namespace for SVG
namespace = '{http://www.w3.org/2000/svg}'

# Find the 'defs' section
defs = root.find(f'{namespace}defs')

# Collect all shape IDs
shape_ids = []
if defs is not None:
    for shape_elem in defs.findall(f'{namespace}g'):
        shape_id = shape_elem.attrib.get('id')
        if shape_id and shape_id.startswith('shape'):
            shape_ids.append(shape_id)

# Generate the include/exclude pattern
total_shapes = len(shape_ids)
print(f"Total shapes: {total_shapes}\n")

for loop_index, shape_id in enumerate(shape_ids, start=1):

    # Create new parse each time
    tree = ET.parse(input_svg_path)
    root = tree.getroot()
    newDef = root.find('{http://www.w3.org/2000/svg}defs')

    print(f"loop{loop_index}:")
    for sid in shape_ids:
        if sid == shape_id:
            #print(f"include {sid}")
            pass
        else:
            for shape_elem in newDef.findall('{http://www.w3.org/2000/svg}g'):
                if shape_elem.attrib.get('id') == sid:
                    newDef.remove(shape_elem)
            #print(f"exclude {sid}")

    # Save the modified SVG with only shape1 (now without shape2)
    new_svg_path = 'shape1_only.svg'
    tree.write(new_svg_path)

    filename = "output" + str(loop_index) + ".png"

    # Convert the new SVG to PNG using cairosvg
    cairosvg.svg2png(url=new_svg_path, write_to=filename,scale=4)

    print(f"Conversion successful! PNG saved as {filename}")

